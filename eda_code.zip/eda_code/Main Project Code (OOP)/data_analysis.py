# External imports
import math
import pandas as pd
import numpy as np
from scipy.stats import linregress
import sqlalchemy
from sqlalchemy import create_engine, MetaData, insert, update, select
from bokeh.plotting import figure, show
# Internal imports
from db_access import data_access
from appendix_b import appendixB


class data_analysis_class():
    """
    This class contains the following methods:
        - map train and ideal functions
        - finding the maximum deviation of train and ideal functions
        - computing the absolute difference between test and ideal functions
        - mapping the ideal functions to the test points
        - plotting the mapped test points 
        - executing the functions in Appendix B of the assignment present in appendix_b.py
    """

    def __init__(self):
        """
        This is the constructor method of the data_analysis_class and is used to to 
        create and properly initialize objects of the required classes, making those objects ready to use.
        """
        self.db_accs_Instance= data_access()
        self.db_accs_Instance.create_train_table()
        self.db_accs_Instance.create_ideal_table()
        self.db_accs_Instance.create_test_table()
        self.train_ideal_mapping()
        self.train_ideal_maxDeviation()
        self.test_ideal_abs_diff()
        self.apxB_inst= appendixB()

    def train_ideal_mapping(self):
        """
        Code for Least-Squares Approach
        This function matches each train function with every ideal function, computes the difference between the squared 'y' values and sums up the values. 
        Next, it identifies the column that returns the minimum value and it assigns that ideal function to the current training function. 
        It repeats the process for all the training function and returns a dictionary which matches each training with its ideal function.
        """
        final_dict={}
        # The for loop iterates over each column name in training functions, excluding the 'x' and 'index' columns
        train_col_name= self.db_accs_Instance.get_train_table().columns.tolist()
        for iter_train in train_col_name:
            if(iter_train!= 'x' and iter_train!= 'index'):
                train_column= self.db_accs_Instance.get_train_table().loc[:,iter_train].values
                train_dict={}
                # The for loop iterates over each column name in ideal functions, excluding the 'x' and 'index' columns
                ideal_col_name= self.db_accs_Instance.get_ideal_table().columns.tolist()
                for iter_ideal in ideal_col_name:
                    if(iter_ideal!= 'x' and iter_ideal!= 'index'):
                        ideal_column= self.db_accs_Instance.get_ideal_table().loc[:,iter_ideal].values
                        # Computing the difference between train and ideal and summing up the values 
                        diff= sum((train_column-ideal_column)**2)
                        train_dict[iter_ideal]=diff
                        min_value= min(train_dict.values())
                        # Finding the ideal function that has the minimum value
                        min_keys = [key for key in train_dict if train_dict[key]==min_value]
                        final_dict[iter_train]=min_keys[0]
        # Returning a dictionary with the training functions along with their respective ideal functions
        return final_dict


    # def train_ideal_mapping(self):
    #     """
    #     Code for Regression Approach
    #     This function computes regression values of training and ideal function. 
    #     Next, it matches each train function with every ideal function, computes the absolute difference between the best fit values and sums up the values.
    #     Subsequently, it identifies the column that returns the minimum value and it assigns that ideal function to the current training function. 
    #     It repeats the process for all the training function and returns a dictionary which matches each training with its ideal function.
    #     """
    #     main_dict= {}
    #     train_x_values= self.db_accs_Instance.get_train_table().loc[:,'x'].values;
    #     # The for loop iterates over each column name in training functions, excluding the 'x' and 'index' columns
    #     train_col_name= self.db_accs_Instance.get_train_table().columns.tolist()
    #     for train_rec in train_col_name:
    #         secondary_dict= {}
    #         if(train_rec!= 'x' and train_rec!= 'index'):
    #             train_column= self.db_accs_Instance.get_train_table().loc[:,train_rec].values;
    #             # Computing regression values of train functions
    #             slope1, intercept1, r_value1, p_value1, std_err1= linregress(train_x_values, train_column)
    #             train_x_arr_values= np.array(train_x_values)
    #             train_y_arr_values= np.array(train_column)
    #             train_est_y= (slope1 * train_x_arr_values) + intercept1
    #             train_est_y_df= pd.DataFrame(train_est_y)
    #             ideal_x_values= self.db_accs_Instance.get_ideal_table().loc[:,'x'].values;
    #             ideal_x_df= pd.DataFrame(ideal_x_values)
    #             # The for loop iterates over each column name in ideal functions, excluding the 'x' and 'index' columns
    #             ideal_col_name= self.db_accs_Instance.get_ideal_table().columns.tolist()
    #             for ideal_rec in ideal_col_name:
    #                 if(ideal_rec!= 'x' and ideal_rec!= 'index'):
    #                     ideal_column= self.db_accs_Instance.get_ideal_table().loc[:,ideal_rec].values;
    #                     # Computing regression values of ideal functions
    #                     slope2, intercept2, r_value2, p_value2, std_err2= linregress(ideal_x_values, ideal_column)
    #                     ideal_x_arr_values= np.array(ideal_x_values)
    #                     ideal_y_arr_values= np.array(ideal_column)
    #                     ideal_est_y= (slope2 * ideal_x_arr_values) + intercept2
    #                     ideal_est_y_df= pd.DataFrame(ideal_est_y)
    #                     # Finding the absolute difference between train and ideal best fit values and summing the values
    #                     diff= sum(abs(train_est_y- ideal_est_y))
    #                     secondary_dict[ideal_rec]= diff
    #             # Finding the ideal function that has the minimum value
    #             min_value= min(secondary_dict.values())
    #             min_keys = [key for key in secondary_dict if secondary_dict[key]==min_value]
    #             main_dict[train_rec]=min_keys[0]
    #     # Returning a dictionary with the training functions along with their respective ideal functions
    #     return main_dict

    # def train_ideal_mapping(self):
    #     """
    #     Code for Correlation Approach
    #     This function matches each train function with every ideal function, computes the correlation between the 'y' values. 
    #     Next, it identifies the column that returns the maximum value and it assigns that ideal function to the current training function. 
    #     It repeats the process for all the training function and returns a dictionary which matches each training with its ideal function.
    #     """    
    #     final_dict={}
    #     # The for loop iterates over each column name in training functions, excluding the 'x' and 'index' columns
    #     train_index= self.db_accs_Instance.get_train_table().columns.tolist()
    #     for iter_train in train_index:
    #         if(iter_train!= 'x' and iter_train!= 'index'):
    #             train_column= self.db_accs_Instance.get_train_table().loc[:,iter_train].values
    #             train_df= pd.DataFrame(train_column, columns = ['y'])
    #             train_dict={}
    #             # The for loop iterates over each column name in ideal functions, excluding the 'x' and 'index' columns
    #             ideal_index_list= self.db_accs_Instance.get_ideal_table().columns.tolist()
    #             for iter_ideal in ideal_index_list:
    #                 if(iter_ideal!= 'x' and iter_ideal!= 'index'):
    #                     ideal_column= self.db_accs_Instance.get_ideal_table().loc[:,iter_ideal].values
    #                     ideal_df= pd.DataFrame(ideal_column, columns = ['y'])
    #                     # Computing the correlation between the 'y' values of train and ideal function 
    #                     calc_correl= train_df['y'].corr(ideal_df['y'])
    #                     train_dict[iter_ideal]=calc_correl
    #             # Finding the ideal function that has the maximum value
    #             max_value= max(train_dict.values())
    #             max_keys = [key for key in train_dict if train_dict[key]==max_value]
    #             # Checking if a ideal function is already assigned to the train. If yes, assign the ideal function to the training function that has the second maximum correaltion between them.
    #             if(max_keys[0] in final_dict.values()):
    #                 values_list = list(train_dict.values())
    #                 values_list.sort(reverse=True)
    #                 second_largest_value = values_list[1]
    #                 for key, value in train_dict.items():
    #                     if value == second_largest_value:
    #                         final_dict[iter_train]=key
    #             else:
    #                 final_dict[iter_train]=max_keys[0]
    #     # Returning a dictionary with the training functions along with their respective ideal functions        
    #     return final_dict


    def train_ideal_maxDeviation(self):   
        """
        This function finds the maximum deviation between the training and ideal data for each function in the  mapping by calculating their absolute difference multiplied by the square root of 2. 
        It returns the maximum deviation value for each function in a dictionary.
        """
        train_dict={}
        # The for loop iterates over each column name in training functions, excluding the 'x' and 'index' columns
        train_col_name= self.db_accs_Instance.get_train_table().columns.tolist()
        for iter_train in train_col_name:
            if(iter_train!= 'x' and iter_train!= 'index'):
                ideal_fns= self.train_ideal_mapping()
                for iter_ideal in ideal_fns: 
                    if(iter_ideal==iter_train):
                        train_column= self.db_accs_Instance.get_train_table().loc[:,iter_train].values
                        ideal_column= self.db_accs_Instance.get_ideal_table().loc[:,ideal_fns.get(iter_ideal)].values
                        # Computing the absolute difference between train and ideal function, multiplying it with sqrt(2) and returning the maximum value
                        diff= max(abs(train_column-ideal_column)) * math.sqrt(2) 
                        train_dict[ideal_fns.get(iter_ideal)]=diff
        # Returning a dictionary containing ideal functions along with their respective max deviation values                
        return train_dict
    
    def test_ideal_abs_diff(self):
        """
        This function returns the absolute difference of 'y' values between test function and the 4 selected ideal functions by matching 'x' their values.
        """
        # Initialize mainList with x-values from the test table
        mainList= []
        testTable_x_values= self.db_accs_Instance.get_test_table().loc[:,'x'].values.tolist()
        mainList.append(testTable_x_values)
        # Iterate over ideal mapping functions and calculate absolute differences
        train_ideal_mapping_fn= self.train_ideal_mapping()
        for value in train_ideal_mapping_fn.values():
            # Get x and y values for the ideal table and calculate estimated y-values using linear regression
            ideal_x_values= self.db_accs_Instance.get_ideal_table().loc[:,'x'].values.tolist(); 
            ideal_x_df= pd.DataFrame(ideal_x_values)
            ideal_column= self.db_accs_Instance.get_ideal_table().loc[:,value].values; 
            ideal_y_df= pd.DataFrame(ideal_column)
            slope, intercept, r_value, p_value, std_err= linregress(ideal_x_values, ideal_column)
            x_arr_values= np.array(ideal_x_values)
            y_arr_values= np.array(ideal_column)
            est_y= (slope * x_arr_values) + intercept
            # Create a DataFrame with the estimated y-values and the x-values from the ideal table
            est_y_df= pd.DataFrame(est_y)
            y_dataframe= pd.concat([ideal_x_df, est_y_df],axis=1); y_dataframe.columns=['x','y']
            # Merge the DataFrame with the estimated y-values with the test table and calculate the absolute difference
            df1= y_dataframe; df2= self.db_accs_Instance.get_test_table() 
            merged_df= pd.merge(df1, df2, on='x'); merged_df.columns=['x','y_ideal','index','y_test','dummy1','dummy2']
            diff= abs(merged_df['y_test']- merged_df['y_ideal']); final_diff= pd.DataFrame(diff); final_diff.columns=['y']
            final_df= pd.concat([merged_df['x'], final_diff],axis=1); final_df.columns=['x','y_diff1']
            # Append the absolute difference values to mainList
            y_values= final_diff.loc[:,'y'].values.tolist()
            mainList.append(y_values)
        # Create the final table with column names
        final_table= pd.DataFrame(mainList).transpose()
        ideal_value_head= train_ideal_mapping_fn.values()
        ideal_value_list= []
        ideal_value_list.insert(0, 'x')
        for ideal_rec in ideal_value_head:
            ideal_value_list.append(ideal_rec)
        final_table.columns= ideal_value_list
        return final_table

    def map_ideal_to_test(self):
        """
        This function compares the values computed by test_ideal_abs_diff() function with the maximum deviation values computed in train_ideal_maxDeviation() function.
        If the result is less than or equal to max dev value then that corresponding ideal function and its respective difference value is updated in the test_functions table.
        """
        # The following code extracts x and y values from a test table using a database access class instance. It then creates an empty list called "data_list" to hold data that will be inserted into the test table.
        x_values= self.db_accs_Instance.get_test_table().loc[:,'x'].values.tolist()
        y_values= self.db_accs_Instance.get_test_table().loc[:,'y'].values.tolist()
        data_list= []
        # The following code establishs a database connection and metadata information for the database.
        eng_conn= self.db_accs_Instance.engine_connect()
        meta = MetaData(bind=eng_conn[0])
        MetaData.reflect(meta)
        conn= eng_conn[1]
        # The following code creates a list by extracting the names of the ideal functions from the "train_ideal_mapping" function.
        ideal_list= []
        train_ideal_mapping_fn= self.train_ideal_mapping()
        ideal_fn_names= train_ideal_mapping_fn.values()
        for id_rec in ideal_fn_names:
            ideal_list.append(id_rec)
        # The following code loops through each ideal function and performs calculations to map the ideal function to the test function based on the criteria
        for ideal_fn_rec in ideal_list:
            train_ideal_max_dev_fn= self.train_ideal_maxDeviation()
            y_max= train_ideal_max_dev_fn.get(ideal_fn_rec)
            test_ideal_abs_diff_fn= self.test_ideal_abs_diff()
            y_diff= test_ideal_abs_diff_fn.loc[:,ideal_fn_rec].values.tolist()
            for x_rec, y_rec, y_val_rec in zip(x_values, y_diff, y_values):
                bulk_dict= {}
                # The following code checks if the value meets the max deviation criteria   
                if(y_rec <= y_max):
                    # The following code checks if 'x' matches with more than 1 ideal function using select query
                    test_table= meta.tables['test_functions']
                    sel= sqlalchemy.select(test_table).where(test_table.c.x == x_rec)
                    check_x= conn.execute(sel).fetchall()[0][3]
                    if(check_x == None):
                        # The following code updates 'Delta Y' and 'No. of ideal func' values
                        u = update(test_table)
                        u = u.values({ "Delta Y": y_rec, "No. of ideal func": ideal_fn_rec})
                        u= u.where(test_table.c.x == x_rec)
                        conn= eng_conn[1]
                        result= conn.execute(u)        
                    if(check_x != None ):
                        check_ideal_y= conn.execute(sel).fetchall()[0][3]
                        if(check_ideal_y != y_rec):
                            # Adding items to dictionary and then to the list to create data object
                            bulk_dict["x"]=x_rec
                            bulk_dict["y"]=y_val_rec
                            bulk_dict["Delta Y"]=y_rec
                            bulk_dict["No. of ideal func"]=ideal_fn_rec
                            data_list.append(bulk_dict)                
        # The following code inserts the data in "data_list" into the test table.        
        ins= test_table.insert().values(data_list)
        conn= eng_conn[1]
        res= conn.execute(ins)
        # The following code orders the data in the test table based on 'x' and also updates the values of unmatched "Delta Y" and "No. of ideal func" column
        ord_list= []
        test_table= meta.tables['test_functions']
        sel= sqlalchemy.select(test_table).order_by(test_table.c.x.asc())
        fetch= conn.execute(sel).fetchall()
        for rec in fetch:
            ord_list.append(rec)
        # Using a counter to match the where clause
        count= 1
        for ord_rec in ord_list:
            if(ord_rec[4] != None):      
                u = update(test_table)
                u = u.values({ "x":ord_rec[1], "y":ord_rec[2], 
                            "Delta Y": ord_rec[3], "No. of ideal func": ord_rec[4]}).where(test_table.c.index == count)
                conn= eng_conn[1]
                result= conn.execute(u)
                count+= 1
            else:
                u = update(test_table)
                u = u.values({ "x":ord_rec[1], "y":ord_rec[2], 
                            "Delta Y": 0, "No. of ideal func": "N/A"}).where(test_table.c.index == count)
                conn= eng_conn[1]
                result= conn.execute(u)
                count+= 1   

    def mapping_test_points(self):
        """
        Generates scatter plots of test data points and their ideal best fit lines with max deviation boundaries.
        """
        # The following code connect to the database and retrieve the necessary tables and data
        eng_conn= self.db_accs_Instance.engine_connect()
        meta = MetaData(bind=eng_conn[0])
        MetaData.reflect(meta)
        conn= eng_conn[1]
        test_table= meta.tables['test_functions']
        # Create a list of ideal function names.
        ideal_list= []
        train_ideal_mapping_fn= self.train_ideal_mapping()
        ideal_fn_names= train_ideal_mapping_fn.values()
        for id_rec in ideal_fn_names:
            ideal_list.append(id_rec)
        # Generate scatter plots for each train function.
        for ideal_rec in ideal_list:
            # Retrieve the test data for the current ideal function.
            sel= sqlalchemy.select(test_table).where(test_table.c['No. of ideal func'] == ideal_rec)
            sel_y= conn.execute(sel).fetchall()
            xlst= []; ylst= []
            for rec in sel_y:
                xlst.append(rec[1])
                ylst.append(rec[2])
            # Generate the scatter plot with the ideal best fit line and max deviation boundaries.
            train_ideal_maxDev_fn= self.train_ideal_maxDeviation()
            max_dev_val= round(train_ideal_maxDev_fn[ideal_rec],3)
            title= f"{ideal_rec} Scatter plot with ideal best fit line with max boundary of {max_dev_val}"
            p= figure(title= title, x_axis_label='X axis', y_axis_label='Y axis')
            p.title.text_font_size = '13pt'
            p.scatter(xlst, ylst, size= 10)
            # Add the ideal best fit line to the plot.
            ideal_list= [ideal_rec]
            for plot_rec in ideal_list: 
                ideal_x= self.db_accs_Instance.get_ideal_table().loc[:,'x'].values
                ideal_y= self.db_accs_Instance.get_ideal_table().loc[:,plot_rec].values
                slope, intercept, r_value, p_value, std_err= linregress(ideal_x, ideal_y)
                xs = np.linspace(np.min(ideal_x), np.max(ideal_x), 100)
                ys = slope * xs + intercept
                p.line(xs, ys, color='red')
                # Add the maximum deviation as upper and lower bounds to the scatter plot
                x_values= np.array(ideal_x)
                est_y= (slope * x_values) + intercept 
                pos_dev_est= est_y + train_ideal_maxDev_fn[plot_rec]
                neg_dev_est= est_y - train_ideal_maxDev_fn[plot_rec]
                p.line(ideal_x, pos_dev_est, color='red')
                p.line(ideal_x, neg_dev_est, color='red')
            # Show the plot
            try:
                show(p) 
            except Exception as _error:
                print(f"Error: Unable to generate the graph: {_error}")  

    def appendix_b_prior_execution(self):
        """
        This function calls various functions of an instance of AppendixB class.
        This function is responsible for generating different graphs and visualizations as well as counting and describing certain parameters.
        """
        self.apxB_inst.train_test_desc()
        self.apxB_inst.train_outliers()
        self.apxB_inst.test_outliers()
        self.apxB_inst.train_box_plots()
        self.apxB_inst.test_box_plot()
        self.apxB_inst.find_dup_train()
        self.apxB_inst.find_dup_test()
        self.apxB_inst.missing_values()
        # Append the output of the functions to a dictionary and print (to make it easier to check values in the Terminal)
        object_dict= {
                      "Train & Test Desc":self.apxB_inst.train_test_desc(), 
                      "Train Outliers": self.apxB_inst.train_outliers(),
                      "Test Outliers": self.apxB_inst.test_outliers(), 
                      "Train Duplicates": self.apxB_inst.find_dup_train(),
                      "Test Duplicates": self.apxB_inst.find_dup_test(), 
                      "Train & Test Missing values": self.apxB_inst.missing_values()
                      }
        print(object_dict)

    def appendix_b_standard_execution(self):
        self.apxB_inst.bestfit_scatter_plots()
        self.apxB_inst.bar_chart_regression()
        self.apxB_inst.bar_chart_correlation()
        self.apxB_inst.bar_chart_leastSquares()
        self.apxB_inst.test_ideal_mapping_count()
        self.apxB_inst.counter_pie_chart()

#start of main code
if __name__ == "__main__":
    """
    This code block is the entry point of the script/application.
    It creates an instance of the data_analysis_class and calls its map_ideal_to_test, mapping_test_points, 
    and appendix_b_fns methods to execute the main functionality of the script.
    """
    data_analysis= data_analysis_class()
    data_analysis.map_ideal_to_test()
    data_analysis.mapping_test_points()
    data_analysis.appendix_b_standard_execution()
    data_analysis.appendix_b_prior_execution()
    


    