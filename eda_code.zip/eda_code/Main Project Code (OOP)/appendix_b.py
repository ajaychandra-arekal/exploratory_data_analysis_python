# External imports
from bokeh.plotting import figure, show
from bokeh.models import ColumnDataSource, Label, Whisker
from bokeh.transform import factor_cmap
from scipy.stats import linregress
import numpy as np
import pandas as pd
import math
from collections import Counter
# Internal imports
from db_access import data_access
from db_access import file_path

class appendixB():
    """
    This class contains all the functions that are part of the appendix B of the assignment
    """
    def __init__(self):
        """
        Initializes the class instance and data frames using the "data_access" class.
        """
        self.db_access_class_instance_2= data_access()
        self.train_df= pd.DataFrame(self.db_access_class_instance_2.get_train_table())
        self.ideal_df= pd.DataFrame(self.db_access_class_instance_2.get_ideal_table())
        self.test_df= pd.DataFrame(self.db_access_class_instance_2.get_test_table())
        self.test_table_read_2()

    def test_table_read_2(self):
        """
        Reading the test functions data from csv file
        """
        path= file_path + "test.csv"
        test_read= pd.read_csv(path).sort_values(by='x').groupby('x', as_index=False).mean()
        test_df= pd.DataFrame(test_read)
        test_read_raw= pd.read_csv(path)
        return test_read, test_df, test_read_raw

    def train_test_desc(self):
        """
        Prints descriptive statistics of the train and test tables using the "describe" function.
        """
        tr_desc= self.db_access_class_instance_2.get_train_table().describe(); print(tr_desc)
        tst_desc= self.test_table_read_2()[0].describe(); print(tst_desc)

    def train_outliers(self):
        """
        Calculates the upper and lower bounds for each column of the train table and counts the number of outliers in each column.
        """
        outier_dict= {}
        col_name= self.train_df.columns.tolist()
        for rec in col_name:
            bounds_dict= {}
            if(rec!= 'x' and rec!= 'index'):
                y_values= self.train_df.loc[:,rec].values.tolist()
                # Finding IQR
                Q1 = np.percentile(y_values, 25, interpolation = 'midpoint')
                Q3 = np.percentile(y_values, 75, interpolation = 'midpoint')
                IQR = Q3 - Q1
                # Finding upper and lower bounds
                uppr_bound= Q3+1.5*IQR
                lowr_bound= Q1-1.5*IQR
                upprcount= 0
                lwrcount= 0
                # Counting the outliers in each column
                for y_rec in y_values:
                    if(y_rec> uppr_bound):
                        upprcount+= 1
                    elif(y_rec< lowr_bound):
                        lwrcount+= 1
                    else:
                        pass     
                bounds_dict['upper bound']= upprcount     
                bounds_dict['lower bound']= lwrcount
                outier_dict[rec]= bounds_dict
        return(outier_dict)
        print(outier_dict) 

    def test_outliers(self):
        """
        Calculates the upper and lower bounds of the test table and counts the number of outliers.
        """
        outier_dict= {}
        bounds_dict= {}
        y_values= self.test_table_read_2()[1].loc[:,'y'].values.tolist()
        # Finding IQR
        Q1 = np.percentile(y_values, 25, interpolation = 'midpoint')
        Q3 = np.percentile(y_values, 75, interpolation = 'midpoint')
        IQR = Q3 - Q1
        # Finding upper and lower bounds
        uppr_bound= Q3+1.5*IQR
        lowr_bound= Q1-1.5*IQR
        upprcount= 0
        lwrcount= 0
        for y_rec in y_values:

            if(y_rec> uppr_bound):
                upprcount+= 1
            elif(y_rec< lowr_bound):
                lwrcount+= 1
            else:
                pass 
            bounds_dict['upper bound']= upprcount     
            bounds_dict['lower bound']= lwrcount
            outier_dict['y']= bounds_dict
        return(outier_dict)
        print(outier_dict)

    def train_box_plots(self):
        """
        Generate box plots for each column in the training data.
        """
        train_list= self.train_df.columns.tolist()
        const_dict= {}; const_name= []; const_y= []; data_dict= {}
        q1_list= []; q2_list= []; q3_list= []
        for rec1 in train_list:
            if(rec1!= 'x' and rec1!= 'index'):
                name_lst= [rec1]*len(self.train_df)
                y_lst= self.train_df[rec1].tolist()
                const_name.extend(name_lst)
                const_y.extend(y_lst)
        const_dict['Train']= const_name
        const_dict['y']= const_y
        df= pd.DataFrame(const_dict)

        trains = df.Train.unique()
        qs = df.groupby("Train").y.quantile([0.25, 0.5, 0.75])
        qs = qs.unstack().reset_index()
        qs.columns = ["Train", "q1", "q2", "q3"]
        df = pd.merge(df, qs, on="Train", how="left")
        # compute IQR outlier bounds
        iqr = df.q3 - df.q1
        df["upper"] = df.q3 + 1.5*iqr
        df["lower"] = df.q1 - 1.5*iqr
        source = ColumnDataSource(df)
        p = figure(x_range=trains, tools="", toolbar_location=None,
                title="Train Box plots",
                background_fill_color="#eaefef", y_axis_label="train")
        # outlier range
        whisker = Whisker(base="Train", upper="upper", lower="lower", source=source)
        whisker.upper_head.size = whisker.lower_head.size = 20
        p.add_layout(whisker)
        # quantile boxes
        color1 = ["pink", "yellow", "lightgreen","orange", "red"]  
        cmap = factor_cmap("Train", color1, trains)
        p.vbar("Train", 0.7, "q2", "q3", source=source, color=cmap, line_color="black")
        p.vbar("Train", 0.7, "q1", "q2", source=source, color=cmap, line_color="black")
        # outliers
        outliers = df[~df.y.between(df.lower, df.upper)]
        p.scatter("Train", "y", source=outliers, size=6, color="black", alpha=0.3)
        p.xgrid.grid_line_color = None
        p.axis.major_label_text_font_size="18px"
        p.axis.axis_label_text_font_size="18px"
        try:
            show(p) 
        except Exception as _error:
            print(f"Error: Unable to generate the graph: {_error}") 

    def test_box_plot(self):
        """
        Generate box plots for each column in the test data.
        """
        const_dict= {}
        name_lst= ['y']*len(self.test_table_read_2()[1])
        y_lst= self.test_table_read_2()[1]['y'].tolist()
        const_dict['Test']= name_lst
        const_dict['y']= y_lst
        df= pd.DataFrame(const_dict)
        tests = df.Test.unique()
        qs = df.groupby("Test").y.quantile([0.25, 0.5, 0.75])
        qs = qs.unstack().reset_index()

        qs.columns = ["Test", "q1", "q2", "q3"]
        df = pd.merge(df, qs, on="Test", how="left")
        # compute IQR outlier bounds
        iqr = df.q3 - df.q1
        df["upper"] = df.q3 + 1.5*iqr
        df["lower"] = df.q1 - 1.5*iqr

        source = ColumnDataSource(df)
        p = figure(x_range=tests, tools="", toolbar_location=None,
                    title="Test Box plot",
                    background_fill_color="#eaefef", y_axis_label="test")
        p.title.text_font_size = '15pt'
        # outlier range
        whisker = Whisker(base="Test", upper="upper", lower="lower", source=source)
        whisker.upper_head.size = whisker.lower_head.size = 20
        p.add_layout(whisker)
        # quantile boxes
        color1 = ["pink", "yellow", "lightgreen","orange", "red"]  
        cmap = factor_cmap("Test", color1, tests)
        p.vbar("Test", 0.7, "q2", "q3", source=source, color=cmap, line_color="black")
        p.vbar("Test", 0.7, "q1", "q2", source=source, color=cmap, line_color="black")
        # outliers
        outliers = df[~df.y.between(df.lower, df.upper)]
        p.scatter("Test", "y", source=outliers, size=6, color="black", alpha=0.3)
        p.xgrid.grid_line_color = None
        p.axis.major_label_text_font_size="18px"
        p.axis.axis_label_text_font_size="18px"
        try:
            show(p) 
        except Exception as _error:
            print(f"Error: Unable to generate the graph: {_error}") 

    def find_dup_train(self):
        """
        Checking for duplicates values in training data
        """
        dup_dict= {}
        col_name= self.train_df.columns.tolist()
        for rec in col_name:
            if(rec != 'index'):
                total_items= len(self.train_df[rec])
                uniq_items= len(self.train_df[rec].unique())
                dup_items= total_items- uniq_items
                dup_dict[rec]= dup_items
        return(dup_dict) 
        print(dup_dict)
  
    def find_dup_test(self):
        """
        Checking for duplicates values in test data
        """
        dup_dict= {}
        col_name= self.test_table_read_2()[1].columns.tolist()
        for rec in col_name:
            if(rec!= 'index' and rec!= 'Delta Y' and rec!= 'No. of ideal func'):
                total_items= len(self.test_table_read_2()[2][rec])
                uniq_items= len(self.test_table_read_2()[2][rec].unique())
                dup_items= total_items- uniq_items
                dup_dict[rec]= dup_items
        return(dup_dict)
        print(dup_dict)


    def missing_values(self):   
        """
        Checking for missing values in train and test data
        """ 
        train_num_missing = self.db_access_class_instance_2.get_train_table().isnull().sum()
        return(train_num_missing)
        print(train_num_missing)
        test_num_missing =self.test_table_read_2()[0].isnull().sum()
        return(train_num_missing)
        print(test_num_missing)

    def bestfit_scatter_plots(self):
        """
        [All approaches]
        Generate scatter plot of training functions with regression lines for specified 'y' columns in the training and ideal dataframes
        """
        method_dict= {"Regression":['y2','y38','y43','y46'], 
                      "Correlation":['y9','y38','y45','y46'], 
                      "Least-Squares":['y9','y38','y43','y46']} 
        ideal_list=[]
        train_list= ['y1','y2','y3','y4']
        for key, value in method_dict.items():
            if(key== "Regression"):
                ideal_list= value  
            elif(key== "Correlation"):
                ideal_list= value  
            else:
                ideal_list= value 
             # Get x and y values from training dataframe
            x_values_train= self.train_df.loc[:,'x'].values.tolist()        
            for train_rec, ideal_rec in zip(train_list, ideal_list): 
                y_values= self.train_df.loc[:,train_rec].values.tolist()
                p= figure(title= f"{key} Approach: Fitting {train_rec} and {ideal_rec} regression lines")
                p.title.text_font_size = '15pt'
                p.scatter(x_values_train, y_values)
                # Calculate regression line for training data
                train_x= self.train_df.loc[:,'x'].values
                train_y= self.train_df.loc[:,train_rec].values
                slope1, intercept1, r_value1, p_value1, std_err1= linregress(train_x, train_y)
                xs1 = np.linspace(np.min(train_x), np.max(train_x))
                ys1 = slope1 * xs1 + intercept1
                p.line(xs1, ys1, color='green', line_width=2.5, legend_label='Train regression line')
                 # Calculate regression line for ideal data
                ideal_x= self.ideal_df.loc[:,'x'].values
                ideal_y= self.ideal_df.loc[:,ideal_rec].values
                slope2, intercept2, r_value2, p_value2, std_err2= linregress(ideal_x, ideal_y)
                xs2 = np.linspace(np.min(ideal_x), np.max(ideal_x))
                ys2 = slope2 * xs2 + intercept2
                p.line(xs2, ys2, color='red', line_width=2.5, legend_label='Ideal regression line')
                # Show the plot
                try:
                    show(p) 
                except Exception as _error:
                    print(f"Error: Unable to generate the graph: {_error}")  

    def bar_chart_regression(self):
        """
        [Regression approach] 
        Generates a bar chart displaying the sum of the absolute deviation of regression values for every ideal function and a given train function.
        """
        main_dict= {}
        # The for loop iterates over each column name in training functions, excluding the 'x' and 'index' columns
        train_x_values= self.db_access_class_instance_2.get_train_table().loc[:,'x'].values
        train_col_name= self.db_access_class_instance_2.get_train_table().columns.tolist()
        for train_rec in train_col_name:
            if(train_rec!= 'x' and train_rec!= 'index'):
                secondary_dict= {}
                train_column= self.db_access_class_instance_2.get_train_table().loc[:,train_rec].values
                # Computing regression values of train functions
                slope1, intercept1, r_value1, p_value1, std_err1= linregress(train_x_values, train_column)
                train_x_arr_values= np.array(train_x_values)
                train_y_arr_values= np.array(train_column)
                train_est_y= (slope1 * train_x_arr_values) + intercept1
                train_est_y_df= pd.DataFrame(train_est_y)
                # The for loop iterates over each column name in ideal functions, excluding the 'x' and 'index' columns
                ideal_x_values= self.db_access_class_instance_2.get_ideal_table().loc[:,'x'].values;
                ideal_x_df= pd.DataFrame(ideal_x_values)
                ideal_col_name= self.db_access_class_instance_2.get_ideal_table().columns.tolist()
                for ideal_rec in ideal_col_name:
                    if(ideal_rec!= 'x' and ideal_rec!= 'index'):
                        ideal_column= self.db_access_class_instance_2.get_ideal_table().loc[:,ideal_rec].values;
                        # Computing regression values of ideal functions
                        slope2, intercept2, r_value2, p_value2, std_err2= linregress(ideal_x_values, ideal_column)
                        ideal_x_arr_values= np.array(ideal_x_values)
                        ideal_y_arr_values= np.array(ideal_column)
                        ideal_est_y= (slope2 * ideal_x_arr_values) + intercept2
                        ideal_est_y_df= pd.DataFrame(ideal_est_y)
                        # Finding the absolute difference between train and ideal best fit values and summing the values
                        diff= sum(abs(train_est_y- ideal_est_y))
                        secondary_dict[ideal_rec]= diff
                # Finding the ideal function that has the minimum value
                min_value= min(secondary_dict.values())
                min_keys = [key for key in secondary_dict if secondary_dict[key]==min_value]
                # Computing the values and properties for the bar chart 
                key_list= list(secondary_dict.keys())
                value_list = np.log10(list(secondary_dict.values()))
                title= f"Regression approach: Finding ideal for '{train_rec}' train functon"
                p = figure(title= title, x_range=key_list, plot_width=1300, plot_height=300)
                p.yaxis.major_label_text_font_size = '8pt'; p.xaxis.major_label_text_font_size = '11pt'
                p.title.text_font_size = '13pt'
                index = key_list.index(min_keys[0])
                colors = ['blue' if i != index else 'red' for i in range(len(value_list))]
                p.vbar(x= key_list, top= value_list, width=0.5, color=colors)
                label = Label(x=1, y=10, text='Min Value', text_font_size='13pt', text_color='red')
                p.add_layout(label)
                label.x = 45; label.y = 6; label.y_offset = 1
                # Show the plot
                try:
                    show(p) 
                except Exception as _error:
                    print(f"Error: Unable to generate the graph: {_error}") 

    def bar_chart_correlation(self):
        """
        [Correlation approach] 
        Generates a bar chart displaying correlation values for every ideal function and a given train function.
        """
        ideal_dict= {'y1': 'y9', 'y2': 'y38', 'y3': 'y45', 'y4': 'y46'}
        # The for loop iterates over each column name in training functions, excluding the 'x' and 'index' columns
        train_col_name= self.db_access_class_instance_2.get_train_table().columns.tolist()
        for train_rec in train_col_name:     
            if(train_rec!= 'x' and train_rec!= 'index'):
                secondary_dict= {}
                train_column= self.db_access_class_instance_2.get_train_table().loc[:,train_rec].values; 
                train_df= pd.DataFrame(train_column, columns = ['y'])
                # The for loop iterates over each column name in ideal functions, excluding the 'x' and 'index' columns
                ideal_col_name= self.db_access_class_instance_2.get_ideal_table().columns.tolist()
                for ideal_rec in ideal_col_name:
                    if(ideal_rec!= 'x' and ideal_rec!= 'index'):
                        ideal_column= self.db_access_class_instance_2.get_ideal_table().loc[:,ideal_rec].values
                        ideal_df= pd.DataFrame(ideal_column, columns = ['y'])
                        # Finding the correlation between train and ideal best fit values
                        calc_correl= train_df['y'].corr(ideal_df['y'])
                        secondary_dict[ideal_rec]=calc_correl
                max_value= max(secondary_dict.values())
                max_keys = [key for key in secondary_dict if secondary_dict[key]==max_value]
                key_list= list(secondary_dict.keys())
                value_list1= list(secondary_dict.values())
                value_list2= [i * 100000 for i in value_list1]
                replace_neg = [max(0, i) for i in value_list2]
                place_zero = [i if i != 0 else 1 for i in replace_neg]
                new_value_list = np.log10(place_zero).tolist()
                # Computing the values and properties for the bar chart              
                title= f"Correlation approach: Finding ideal for '{train_rec}' train functon"
                p = figure(title= title, x_range=key_list, plot_width=1300, plot_height=300)
                p.yaxis.major_label_text_font_size = '8pt'; p.xaxis.major_label_text_font_size = '11pt'
                p.title.text_font_size = '13pt'
                index = key_list.index(max_keys[0])
                colors = ['blue' if i != ideal_dict[train_rec] else 'red' for i in key_list]
                p.vbar(x= key_list, top= new_value_list, width=0.5, color=colors)
                label = Label(x=1, y=10, text='Max Value', text_font_size='10pt', text_color='red')
                p.add_layout(label)
                label.x = 47; label.y = 4.75; label.y_offset = 1
                # Show the plot
                try:
                    show(p) 
                except Exception as _error:
                    print(f"Error: Unable to generate the graph: {_error}") 


    # Bar chart to show ideal and y values [Least-squares approach] executed for individual train function
    def bar_chart_leastSquares(self):
        """
        [Least-squares approach] 
        Generates a bar chart displaying the sum of the squared deviation of ideal function and a given train function.
        """
        main_dict= {}
        # The for loop iterates over each column name in training functions, excluding the 'x' and 'index' columns
        train_x_values= self.db_access_class_instance_2.get_train_table().loc[:,'x'].values
        train_col_name= self.db_access_class_instance_2.get_train_table().columns.tolist()
        for train_rec in train_col_name:     
            if(train_rec!= 'x' and train_rec!= 'index'):
                secondary_dict= {}
                train_column= self.db_access_class_instance_2.get_train_table().loc[:,train_rec].values    
                ideal_x_values= self.db_access_class_instance_2.get_ideal_table().loc[:,'x'].values;
                ideal_x_df= pd.DataFrame(ideal_x_values)
                # The for loop iterates over each column name in ideal functions, excluding the 'x' and 'index' columns
                ideal_col_name= self.db_access_class_instance_2.get_ideal_table().columns.tolist()
                for ideal_rec in ideal_col_name:
                    if(ideal_rec!= 'x' and ideal_rec!= 'index'):
                        ideal_column= self.db_access_class_instance_2.get_ideal_table().loc[:,ideal_rec].values
                        # Finding the squared difference between train and ideal functions and summing the values
                        diff= sum((train_column- ideal_column)**2)
                        secondary_dict[ideal_rec]= diff
                min_value= min(secondary_dict.values())
                min_keys = [key for key in secondary_dict if secondary_dict[key]==min_value]
                key_list= list(secondary_dict.keys())
                value_list = np.log10(list(secondary_dict.values()))
                # Computing the values and properties for the bar chart 
                title= f"Least-squares approach: Finding ideal for '{train_rec}' train functon"
                p = figure(title= title, x_range=key_list, plot_width=1300, plot_height=300)
                p.yaxis.major_label_text_font_size = '8pt'; p.xaxis.major_label_text_font_size = '11pt'
                p.title.text_font_size = '13pt'
                index = key_list.index(min_keys[0])
                colors = ['blue' if i != index else 'red' for i in range(len(value_list))]
                p.vbar(x= key_list, top= value_list, width=0.5, color=colors)
                label = Label(x=1, y=10, text='Min Value', text_font_size='13pt', text_color='red')
                p.add_layout(label)
                # Show the plot
                try:
                    show(p) 
                except Exception as _error:
                    print(f"Error: Unable to generate the graph: {_error}") 

    # Test-ideal mapping counter
    def test_ideal_mapping_count(self):
        """
        This function checks for the count of test points that have been mapped multiple times
        """
        mapped_ideal_val= self.db_access_class_instance_2.get_test_table().loc[:,'No. of ideal func'].values
        result_dict = dict(Counter(mapped_ideal_val))
        mapped_ideal_x_val= self.db_access_class_instance_2.get_test_table().loc[:,'x'].values
        x_counter= dict(Counter(mapped_ideal_x_val))
        rep_count= 0
        for rec in x_counter.values():
            if(rec > 1):
                rep_count+= 1
        result_dict['multiple mappings']= rep_count
        print(result_dict) 


    # Pie chart that shows the results of all the approaches by comparing test-ideal mapping 
    def counter_pie_chart(self): 
        """
        This function generates pie charts for different methods to showcase the portion of test-ideal mapping count in the method. 
        The function takes no arguments, and the values are hardcoded in the function itself.
        """
        # Define fields, percentages, and title for each method
        reg_fields= ["y2 (2.099)", "y38 (0.707)", "y43 (0.706)", "y46 (0.706)", "N/A"]; 
        reg_percentages= [36.6, 8.2, 18.3, 8.2, 28.7]; reg_title= "Regression approach"
        corr_fields= ["y9 (0.699)", "y38 (0.707)", "y45 (14.848)", "y46 (0.706)", "N/A"]; 
        corr_percentages= [10, 7.5, 60.8, 7.5, 14.2]; corr_title= "Correlation approach"
        ls_fields= ["y9 (0.699)", "y38 (0.707)", "y43 (0.706)", "y46 (0.706)", "N/A"]; 
        ls_percentages= [12.2, 9.1, 20.4, 9.1, 49.2]; ls_title= "Least-squares approach"
        
        method_dict= ["regr", "corr", "ls"]
        field_var= [];pct_var= []; title_var="";
        # Loop through each method, set the fields, percentages, and title accordingly, and generate the pie chart
        for rec in method_dict:
            if(rec== "regr"):
                field_var= reg_fields; pct_var= reg_percentages; title_var= reg_title
            elif(rec== "corr"):
                field_var= corr_fields; pct_var= corr_percentages; title_var= corr_title
            else:
                field_var= ls_fields; pct_var= ls_percentages; title_var= ls_title
            # Instantiate the figure object    
            graph1 = figure(title = f"{title_var}: Test-ideal mapping count") 
            graph1.title.text_font_size = "18pt"
            # Define fields for investment 
            fields = field_var
            # Define percentage weightage of the sectors  
            percentages = pct_var
            # Convert percentage into radians
            radians1 = [math.radians((percent / 100) * 360) for percent in percentages]   
            # Generating the start angle values  
            start_angle = [math.radians(0)]  ; prev = start_angle[0]  
            for k in radians1[:-1]:  
                start_angle.append(k + prev)  
                prev = k + prev    
            # generating the end angle values  
            end_angle = start_angle[1:] + [math.radians(0)]    
            # Set the center of the pie chart   
            x = 0 ;y = 0    
            # Set the radius of the glyphs  
            radius = 1    
            # now, generate the color of the wedges  
            color1 = ["pink", "yellow", "lightgreen","orange", "red"]    
            # Plot the graph  
            for k in range(len(fields)):  
                graph1.wedge(x, y, radius,  
                            start_angle = start_angle[k],  
                            end_angle = end_angle[k],  
                            color = color1[k],  
                            legend_label = fields[k]) 
            graph1.legend.label_text_font_size = '19pt'
            # Display the graph  
            try:
                show(graph1) 
            except Exception as _error:
                print(f"Error: Unable to generate the graph: {_error}") 



    