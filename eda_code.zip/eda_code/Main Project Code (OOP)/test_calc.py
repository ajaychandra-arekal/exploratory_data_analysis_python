# External imports
import unittest
# Internal imports
from data_analysis import data_analysis_class

class TestCalc(unittest.TestCase):
    """
    This class defines the unit tests for the methods in the data_analysis_class.
    """

    def testing_train_ideal_mapping_fn(self):
        """
        Tests the train_ideal_mapping method in the data_analysis_class. 
        It checks that the method returns a non-None object and that the length of the returned object is 4.
        """
        obj= data_analysis_class()
        self.assertIsNotNone(obj.train_ideal_mapping())
        self.assertEqual(len(obj.train_ideal_mapping()), 4)


    def testing_train_ideal_maxDeviation_fn(self):
        """
        Tests the train_ideal_maxDeviation method in the data_analysis_class. 
        It checks that the method returns a non-None object and that the length of the returned object is 4.
        """
        obj= data_analysis_class()
        self.assertIsNotNone(obj.train_ideal_maxDeviation())
        self.assertEqual(len(obj.train_ideal_maxDeviation()), 4)

    def testing_test_ideal_abs_diff_fn(self):
        """
        Tests the test_ideal_abs_diff method in the data_analysis_class. 
        It checks that the method returns a non-None object.   
        """
        obj= data_analysis_class()
        self.assertIsNotNone(obj.test_ideal_abs_diff())