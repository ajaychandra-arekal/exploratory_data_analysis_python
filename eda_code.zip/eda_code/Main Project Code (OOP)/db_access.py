# External Imports
import sqlalchemy
from sqlalchemy import create_engine, MetaData, Table, Column, Integer, String, text, insert, Float
import pandas as pd

db_path= "others_code1.db"
# file_path= "/Users/ajaychandraas/Desktop/Datasets written assignment-231-4 2/"
file_path= "/Users/ajaychandraas/Desktop/input_analysis_data/"

"""
The above code sets the db_path variable to the path of the SQLite database that will be created,
and the file_path variable to the path of the directory that contains the CSV files.
"""

class data_access():
    """
    This class contains methods for creating tables in a SQLite database, retrieving data from these tables, and connecting to the database
    """

    def __init__(self):
       """
       This is the constructor method of the data_access class. It calls the engine_connect() method to connect to the database.
       """
       self.engine_connect()

    def engine_connect(self):
        """
        This function creates a connection to the SQLite database specified by db_path. 
        If the connection is successful, it returns the engine and connection objects.
        """
        try:
            engine= create_engine(f'sqlite:///{db_path}', echo=True)
            conn = engine.connect()
            return engine, conn
        except Exception as _error:
            print(f"Error: Database Engine creating unsuccessfull: {_error}")

    def create_train_table(self):
        """
        This function creates a table in the database named training_functions, 
        which is populated with data from the train.csv file located in the file_path directory.
        """
        try:
            eng_conn= self.engine_connect()
            path= file_path + "train.csv"
            df = pd.read_csv(path)
            create_table= df.to_sql("training_functions", eng_conn[0])
        except Exception as _error:
            print(f"Error: training_functions table creation was unsuccessfull: {_error}")

    def create_ideal_table(self):
        """
        This function creates a table in the database named ideal_functions, 
        which is populated with data from the ideal.csv file located in the file_path directory.
        """
        try:
            eng_conn= self.engine_connect()
            path= file_path + "ideal.csv"
            df= pd.read_csv(path)
            create_table= df.to_sql("ideal_functions", eng_conn[0])
        except Exception as _error:
            print(f"Error: ideal_functions table creation was unsuccessfull: {_error}")

    def create_test_table(self):
        try:
            eng_conn= self.engine_connect()[0]
            conn_db= self.engine_connect()[1]
            """
            reading the test functions data from csv file, sorting the 'x' column values in ascending order
            removing the 'x' duplicate values by taking the mean 'y' values
            """
            path= file_path + "test.csv"
            df= pd.read_csv(path).sort_values(by='x').groupby('x', as_index=False).mean()
            """
            creating the schema for the test table
            """
            meta= MetaData()
            testTable= Table(
                        'test_functions',meta,
                        Column('index',Integer,primary_key=True),
                        Column('x',Float),
                        Column('y',Float),
                        Column('Delta Y',Float),
                        Column('No. of ideal func',String)
            )
            meta.create_all(eng_conn)
            """
            inserting the x and y columns line by line to the test table
            """
            for rec in range(0,len(df)):
                c1= df.iloc[rec][0]
                c2= df.iloc[rec][1]
                ins= testTable.insert().values(x=c1, y=c2)
                result= conn_db.execute(ins)
        except Exception as _error:
            print(f"Error: test_functions table creation was unsuccessfull: {_error}")

    def get_train_table(self):
        """
        This function reads the table "training_functions" from SQL database and returns a Pandas DataFrame using SQLAlchemy
        """
        conn_db= self.engine_connect()[1]
        get_train= pd.read_sql_table("training_functions", conn_db)
        return get_train

    def get_ideal_table(self):
        """
        This function reads the table "ideal_functions" from SQL database and returns a Pandas DataFrame using SQLAlchemy
        """
        conn_db= self.engine_connect()[1]
        get_ideal= pd.read_sql_table("ideal_functions", conn_db)
        return get_ideal

    def get_test_table(self):
        """
        This function reads the table "test_functions" from SQL database and returns a Pandas DataFrame using SQLAlchemy
        """
        conn_db= self.engine_connect()[1]
        get_test= pd.read_sql_table("test_functions", conn_db)
        return get_test
    


    
